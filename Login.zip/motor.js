function logar(){
    var usuario = document.getElementById("usuario");
    var senha = document.getElementById("senha");
    
    console.log(usuario.value+senha);

    if(usuario.value == "kauacesari" && senha.value == "kaua1234"){
        alert("Acesso Permitido!")
    }
    else{ 
        alert("Usuário ou senha não são válidos!");
    }
}